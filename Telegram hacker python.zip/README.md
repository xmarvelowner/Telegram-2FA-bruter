# Hacking Any Telegram Account (Two Factor Authentication Bypass)

Telegram Account Hacking or Cloning Latest Tool.


# Tool Requirements

 + Net Usage : 20 Mb

+ Storage 50mb Above

+ Stable Connection

# Fast Hack Any Telegram Account

+ 2FA auto bypass


# Tool Features

+ Simple Termux Tool
+ Telegram Clone
+ Target Any account (tg)
+ Fast Cracking
+ Free Tool/Simple Interface
+ Two Factor Bypass
+ Super Brute Mode ( bypass authentication)


# Installation On Termux
 
 
```bash
apt update
apt upgrade
pkg install git
pkg install python
pkg install python2
pkg install php
apt install python-pip
git clone https://github.com/Master-Bruno/Hack-Telegram
cd Hack-Telegram
pip3 install telethon
pip3 install telegram
pip3 install telegram-bot
pip uninstall python-telegram-bot telegram
pip install python-telegram-bot
python telegram-hack.py

```
Installation Successful......

Any Error :- First login with your account.Then create the connection with your target Telegram account. After that the account can be hacked automatically. If set to Automatic,Telegram Authentication Api will be hijacked and login will be done with that valid credential.


# Disclaimer
Note
Education purpose only.. Iam not responsible your actions

-@xMarvelOwner
